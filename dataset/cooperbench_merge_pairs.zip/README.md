# CooperBench Merge-Conflict Pairs (20 labeled examples)

Source: [CooperBench](https://cooperbench.com) — *"CooperBench: Why Coding Agents
Cannot be Your Teammates Yet"* ([arXiv:2601.13295](https://arxiv.org/abs/2601.13295),
[GitHub](https://github.com/cooperbench/CooperBench)).

CooperBench pairs two independently-implemented features from the same real-world
pull request and checks whether the two resulting patches merge cleanly. This
dataset materializes 20 of those feature pairs (652 exist in total) as concrete
three-way-merge source trees, with each pair labeled `conflict` or `clean_merge`
using CooperBench's own gold conflict report (`git merge-file` ground truth).

## Layout

```
pair_NN_<repo>_t<task_id>_f<A>v<B>/
├── meta.json          # repo, base commit, feature titles, label, patch-apply status
├── feature_a.md        # human-readable description of feature A (branch_a)
├── feature_b.md        # human-readable description of feature B (branch_b)
├── merge_base/          # common ancestor: only the files touched by either feature,
│                        #  extracted from the real repo at the task's base commit
├── branch_a/            # merge_base + feature A's patch (+ its test patch) applied
└── branch_b/             # merge_base + feature B's patch (+ its test patch) applied
```

`merge_base` is trimmed to just the files either feature touches (repos like
llama_index/Pillow are 50–250MB in full; the untouched 99.9% is irrelevant to
merge behavior, per CooperBench's own finding that features average 1.4 files /
52 changed lines). Files newly created by a feature patch legitimately don't
exist in `merge_base` — see `files_missing_from_snapshot` in `meta.json` for
those (all confirmed as new-file patches, not extraction errors).

## Label

`meta.json.label` (`"conflict"` or `"clean_merge"`) reflects whether
`git merge-file` on the two patches conflicts, taken directly from
CooperBench's `dataset/gold_conflict_report.json`. This is the target
label for a model/agent trying to predict "will these two branches merge
cleanly?" from the three trees.

## Composition (aiming for language + label diversity)

| # | Repo | Lang | Task | Features | Label |
|---|------|------|------|----------|-------|
| 01 | dottxt-ai/outlines | Python | 1655 | 9 vs 10 | conflict |
| 02 | dottxt-ai/outlines | Python | 1655 | 3 vs 9 | clean_merge |
| 03 | stanfordnlp/dspy | Python | 8587 | 3 vs 5 | conflict |
| 04 | stanfordnlp/dspy | Python | 8563 | 1 vs 2 | clean_merge |
| 05 | go-chi/chi | Go | 26 | 2 vs 3 | conflict |
| 06 | go-chi/chi | Go | 56 | 2 vs 4 | clean_merge |
| 07 | huggingface/datasets | Python | 6252 | 3 vs 5 | conflict |
| 08 | huggingface/datasets | Python | 6252 | 1 vs 3 | clean_merge |
| 09 | run-llama/llama_index | Python | 18813 | 1 vs 3 | conflict |
| 10 | run-llama/llama_index | Python | 17244 | 3 vs 4 | clean_merge |
| 11 | openai/tiktoken | Python | 0 | 1 vs 3 | conflict |
| 12 | pallets/click | Python | 2068 | 2 vs 4 | conflict |
| 13 | pallets/click | Python | 2956 | 3 vs 8 | clean_merge |
| 14 | pallets/jinja | Python | 1621 | 1 vs 6 | conflict |
| 15 | pallets/jinja | Python | 1559 | 2 vs 7 | clean_merge |
| 16 | python-pillow/Pillow | Python | 290 | 1 vs 5 | conflict |
| 17 | python-pillow/Pillow | Python | 25 | 1 vs 5 | clean_merge |
| 18 | react-hook-form/react-hook-form | TypeScript | 85 | 1 vs 3 | conflict |
| 19 | samuelcolvin/dirty-equals | Python | 43 | 1 vs 3 | conflict |
| 20 | typst/typst | Rust | 6554 | 6 vs 8 | conflict |

13 conflict / 7 clean_merge, spanning Python, Go, TypeScript, and Rust,
across 12 distinct source repositories.

## Provenance / how this was built

1. Cloned `cooperbench/CooperBench` (MIT-licensed) to get `dataset/gold_conflict_report.json`
   (652 pair-level conflict labels) and each task's `setup.sh` (base commit) and
   `featureN/{feature.md,feature.patch,tests.patch}`.
2. For each selected pair, fetched the real upstream repo tree at the exact base
   commit via GitHub codeload tarballs, keeping only the files either feature's
   patch touches → `merge_base/`.
3. Copied `merge_base/` twice and applied feature A's patch+tests to one copy
   (`branch_a/`) and feature B's patch+tests to the other (`branch_b/`) with
   `patch -p1`. All 20 pairs applied cleanly (see `patch_apply_status` in each
   `meta.json`).
4. Attached the conflict/clean-merge label from CooperBench's gold report.

`index.json` aggregates all 20 `meta.json` records in one file.
