package chi

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestMetricsCollector(t *testing.T) {
	var collectedMetric RouteMetric

	collector := &SimpleMetricsCollector{
		OnHit: func(metric RouteMetric) {
			collectedMetric = metric
		},
	}

	r := NewRouter()
	r.SetMetricsCollector(collector)

	r.Get("/users/{id}", func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(5 * time.Millisecond) // Simulate some work
		w.Write([]byte("user"))
	})

	ts := httptest.NewServer(r)
	defer ts.Close()

	resp, _ := testRequest(t, ts, "GET", "/users/123", nil)
	if resp == nil {
		t.Fatal("failed to make request")
	}
	defer resp.Body.Close()

	// Verify the metrics were collected properly
	if collectedMetric.Pattern != "/users/{id}" {
		t.Errorf("expected pattern '/users/{id}', got '%s'", collectedMetric.Pattern)
	}

	if collectedMetric.Method != "GET" {
		t.Errorf("expected method 'GET', got '%s'", collectedMetric.Method)
	}

	if collectedMetric.Path != "/users/123" {
		t.Errorf("expected path '/users/123', got '%s'", collectedMetric.Path)
	}

	if collectedMetric.Duration < 5*time.Millisecond {
		t.Errorf("expected duration at least 5ms, got %v", collectedMetric.Duration)
	}

	if len(collectedMetric.Params) != 1 {
		t.Errorf("expected 1 param, got %d", len(collectedMetric.Params))
	}

	if val, ok := collectedMetric.Params["id"]; !ok || val != "123" {
		t.Errorf("expected param 'id' with value '123', got '%s'", val)
	}
}

// testRequest is a helper to make HTTP requests for testing
// Assumes testRequest is defined elsewhere in the test package
