package chi

import (
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestVersionSelector(t *testing.T) {
	r := NewRouter()

	selector := NewVersionSelector("v1")

	// Create our versioned handlers
	v1Handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("v1"))
	})

	v2Handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("v2"))
	})

	// Add handlers for the same pattern but different versions
	selector.AddHandler("/api/resource", "v1", v1Handler)
	selector.AddHandler("/api/resource", "v2", v2Handler)

	// Middleware to add the selector to all requests
	r.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			r = WithRouteSelector(r, selector)
			next.ServeHTTP(w, r)
		})
	})

	// Default handler
	r.Get("/api/resource", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("default"))
	})

	ts := httptest.NewServer(r)
	defer ts.Close()

	// Test default version (v1)
	resp, body := testRequest(t, ts, "GET", "/api/resource", nil)
	if resp.StatusCode != 200 || body != "v1" {
		t.Fatalf("expected v1 response, got %s", body)
	}

	// Test explicit v1 via query param
	resp, body = testRequest(t, ts, "GET", "/api/resource?version=v1", nil)
	if resp.StatusCode != 200 || body != "v1" {
		t.Fatalf("expected v1 response, got %s", body)
	}

	// Test v2 via query param
	resp, body = testRequest(t, ts, "GET", "/api/resource?version=v2", nil)
	if resp.StatusCode != 200 || body != "v2" {
		t.Fatalf("expected v2 response, got %s", body)
	}

	// Test v2 via Accept header
	req, _ := http.NewRequest("GET", ts.URL+"/api/resource", nil)
	req.Header.Set("Accept", "application/json;version=v2")
	resp, body = testClient(t, req)
	if resp.StatusCode != 200 || body != "v2" {
		t.Fatalf("expected v2 response, got %s", body)
	}

	// Test unknown version should use default handler
	resp, body = testRequest(t, ts, "GET", "/api/resource?version=v3", nil)
	if resp.StatusCode != 200 || body != "default" {
		t.Fatalf("expected default response, got %s", body)
	}
}

func TestRoleBasedSelector(t *testing.T) {
	r := NewRouter()

	// Role extractor from request header
	roleExtractor := func(r *http.Request) string {
		return r.Header.Get("X-User-Role")
	}

	selector := NewRoleBasedSelector(roleExtractor, "user")

	// Create handlers for different roles
	adminHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("admin"))
	})

	userHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("user"))
	})

	// Add handlers for the same pattern but different roles
	selector.AddHandler("/dashboard", "admin", adminHandler)
	selector.AddHandler("/dashboard", "user", userHandler)

	// Middleware to add the selector to all requests
	r.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			r = WithRouteSelector(r, selector)
			next.ServeHTTP(w, r)
		})
	})

	// Default handler
	r.Get("/dashboard", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("default"))
	})

	ts := httptest.NewServer(r)
	defer ts.Close()

	// Test admin role
	req, _ := http.NewRequest("GET", ts.URL+"/dashboard", nil)
	req.Header.Set("X-User-Role", "admin")
	resp, body := testClient(t, req)
	if resp.StatusCode != 200 || body != "admin" {
		t.Fatalf("expected admin response, got %s", body)
	}

	// Test user role
	req, _ = http.NewRequest("GET", ts.URL+"/dashboard", nil)
	req.Header.Set("X-User-Role", "user")
	resp, body = testClient(t, req)
	if resp.StatusCode != 200 || body != "user" {
		t.Fatalf("expected user response, got %s", body)
	}

	// Test unknown role should default to user
	req, _ = http.NewRequest("GET", ts.URL+"/dashboard", nil)
	req.Header.Set("X-User-Role", "guest")
	resp, body = testClient(t, req)
	if resp.StatusCode != 200 || body != "default" {
		t.Fatalf("expected default response, got %s", body)
	}
}

func testClient(t *testing.T, req *http.Request) (*http.Response, string) {
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
		return nil, ""
	}
	defer resp.Body.Close()

	body := ""
	if resp.Body != nil {
		data, err := io.ReadAll(resp.Body)
		if err != nil {
			t.Fatal(err)
			return nil, ""
		}
		body = string(data)
	}

	return resp, body
}
