package chi

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestInvalidMethod(t *testing.T) {
	r := NewRouter()
	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("root"))
	})

	ts := httptest.NewServer(r)
	defer ts.Close()

	// Test default handler for invalid method
	t.Run("Default handler for invalid method", func(t *testing.T) {
		// Create custom request with invalid method
		req, err := http.NewRequest("INVALID", ts.URL+"/", nil)
		if err != nil {
			t.Fatal(err)
		}

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != 405 {
			t.Errorf("Expected 405 status for invalid method to existing route, got %d", resp.StatusCode)
		}
	})

	// Test 405 for valid method
	t.Run("Normal 405 for valid method", func(t *testing.T) {
		resp, body := testRequest(t, ts, "POST", "/", nil)
		if resp.StatusCode != 405 {
			t.Fatalf("Expected 405 status, got %d", resp.StatusCode)
		}
		if len(body) > 0 {
			t.Fatalf("Expected empty body, got '%s'", body)
		}
	})

	// Test custom invalid method handler
	t.Run("Custom handler for invalid method", func(t *testing.T) {
		r := NewRouter()
		r.Get("/", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("root"))
		})

		// Set custom invalid method handler
		r.SetInvalidMethodHandler(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(418) // I'm a teapot
			w.Write([]byte("custom invalid method"))
		})

		ts := httptest.NewServer(r)
		defer ts.Close()

		// Test with invalid method
		req, err := http.NewRequest("INVALID", ts.URL+"/", nil)
		if err != nil {
			t.Fatal(err)
		}

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != 418 {
			t.Errorf("Expected 418 status for custom invalid method handler, got %d", resp.StatusCode)
		}
	})

	// Test ValidMethod helper function
	t.Run("ValidMethod helper function", func(t *testing.T) {
		if !ValidMethod("GET") {
			t.Error("GET should be a valid method")
		}

		if !ValidMethod("POST") {
			t.Error("POST should be a valid method")
		}

		if ValidMethod("INVALID") {
			t.Error("INVALID should not be a valid method")
		}
	})

	// Test GetAllMethods helper function
	t.Run("GetAllMethods helper function", func(t *testing.T) {
		methods := GetAllMethods()
		expected := 9 // GET, HEAD, POST, PUT, PATCH, DELETE, CONNECT, OPTIONS, TRACE

		if len(methods) != expected {
			t.Errorf("Expected %d standard methods, got %d", expected, len(methods))
		}

		// Check that common methods are included
		foundGet := false
		foundPost := false

		for _, m := range methods {
			if m == "GET" {
				foundGet = true
			}
			if m == "POST" {
				foundPost = true
			}
		}

		if !foundGet {
			t.Error("GET method not found in GetAllMethods()")
		}

		if !foundPost {
			t.Error("POST method not found in GetAllMethods()")
		}
	})

	// Test with a custom registered method
	t.Run("Custom registered method", func(t *testing.T) {
		r := NewRouter()

		// Register custom method
		RegisterMethod("CUSTOM")

		r.MethodFunc("CUSTOM", "/custom", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("custom method"))
		})

		ts := httptest.NewServer(r)
		defer ts.Close()

		// Custom registered method should work
		req, err := http.NewRequest("CUSTOM", ts.URL+"/custom", nil)
		if err != nil {
			t.Fatal(err)
		}

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}

		if resp.StatusCode != 200 {
			t.Errorf("Expected 200 status for custom registered method, got %d", resp.StatusCode)
		}

		// Verify it's recognized as valid
		if !ValidMethod("CUSTOM") {
			t.Error("CUSTOM should be a valid method after registration")
		}
	})
}
