package middleware

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/go-chi/chi/v5"
)

func TestMethodValidator(t *testing.T) {
	r := chi.NewRouter()

	// Set up route with method validation (only GET and POST allowed)
	r.Group(func(r chi.Router) {
		r.Use(MethodValidator(http.MethodGet, http.MethodPost))

		r.Get("/resource", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("get"))
		})

		r.Post("/resource", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("post"))
		})

		r.Put("/resource", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("put"))
		})
	})

	// Test allowed methods
	ts := httptest.NewServer(r)
	defer ts.Close()

	t.Run("Allowed GET", func(t *testing.T) {
		resp, err := http.Get(ts.URL + "/resource")
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != 200 {
			t.Errorf("Expected 200 status, got %d", resp.StatusCode)
		}
	})

	t.Run("Allowed POST", func(t *testing.T) {
		resp, err := http.Post(ts.URL+"/resource", "text/plain", nil)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != 200 {
			t.Errorf("Expected 200 status, got %d", resp.StatusCode)
		}
	})

	t.Run("Disallowed PUT", func(t *testing.T) {
		req, err := http.NewRequest(http.MethodPut, ts.URL+"/resource", nil)
		if err != nil {
			t.Fatal(err)
		}

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != 405 {
			t.Errorf("Expected 405 status, got %d", resp.StatusCode)
		}

		allow := resp.Header.Get("Allow")
		if allow != "GET, POST" {
			t.Errorf("Expected Allow header 'GET, POST', got '%s'", allow)
		}
	})
}

func TestMethodValidatorWithNoMethods(t *testing.T) {
	r := chi.NewRouter()

	// Test with no methods specified (should allow standard methods)
	r.Group(func(r chi.Router) {
		r.Use(MethodValidator()) // No methods specified, should allow standard methods

		r.Get("/standard", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte("standard-get"))
		})
	})

	ts := httptest.NewServer(r)
	defer ts.Close()

	// Test standard method (should be allowed)
	resp, err := http.Get(ts.URL + "/standard")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		t.Errorf("Expected 200 status for standard method, got %d", resp.StatusCode)
	}

	// Test non-standard method (should be rejected)
	req, err := http.NewRequest("CUSTOM", ts.URL+"/standard", nil)
	if err != nil {
		t.Fatal(err)
	}

	resp, err = http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != 405 {
		t.Errorf("Expected 405 status for non-standard method, got %d", resp.StatusCode)
	}
}
